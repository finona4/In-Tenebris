import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Keys here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Keys extends Actor
{
    //an array to hold all the key's animation frames
    private GreenfootImage[] keyImages = new GreenfootImage[12];
    //an int to keep track of the current image index
    private int currImage = 0;
    //an int to represent the speed of the animation
    private static final int SPEED = 5;
    //an int to represent the delay in the animation
    private int delay = 0;
    //an int to make sure the jingle is only played once
    int counter = 0;
    //keeps track of whether the key should be removed or not
    boolean remove = false;
    /**
     * Keys Constructor
     * Load each frame onto the array
     */
    public Keys()
    {
        for(int i = 0; i<keyImages.length; i++)
        {
            keyImages[i] = new GreenfootImage("key"+(i)+".png");
            keyImages[i].scale(40,60);
        }
        setImage(keyImages[0]);
    }

    /**
     * Act - do whatever the Keys wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        animate();
    }    

    /**
     * Method animate
     * Animate the key
     */
    private void animate()
    {
        delay++;
        if (delay==SPEED)
        {
            currImage++;
            if(currImage>=keyImages.length)
            {
                currImage=0;
            }
            setImage(keyImages[currImage]); 
            delay = 0;
        }  
    }

    /**
     * Method getCollected
     * Used by the Player class
     * Return whether the key has been touched by the Player (remove this key)
     * - Or if it's only in its range (play a jingle)
     * @param gotCollected A parameter
     */
    public void getCollected(boolean gotCollected)
    {
        remove = gotCollected;
        if(remove==false)
        {
            counter++;
            if(counter==1)
            {
                Greenfoot.playSound("jingle.mp3");
            }
        }
        if(remove==true)
        {
            Greenfoot.playSound("keysound.mp3");
            getWorld().removeObject(this);
        }
    }
}
