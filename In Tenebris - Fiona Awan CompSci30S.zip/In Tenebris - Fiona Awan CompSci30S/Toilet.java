import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Toilet here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Toilet extends theFurniture
{
    public Toilet()
    {
        getImage().scale(50, 70);
    }

    /**
     * Act - do whatever the Toilet wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
}
