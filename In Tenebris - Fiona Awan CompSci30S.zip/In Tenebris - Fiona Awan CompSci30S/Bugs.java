import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Bugs here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bugs extends Actor
{
    //an int to create a probablity for each bug image
    int randomBug = Greenfoot.getRandomNumber(7);
    //will store the initial y value
    int initialY;
    //counts each iteration
    int counter=0;
    //counts how long the bug has been touching the player
    int attackCounter=0;
    healthBar h = new healthBar();
    /**
     * Bugs Constructor
     * There is a 2 in 7 chance the bug will be an ant, ant with food, or fly
     * And a 1 in 7 chance the bug will be a spider
     */
    public Bugs()
    {
        if(randomBug >=0 && randomBug <2)
        {
            setImage("ant3.png");
        }
        if(randomBug >= 2 && randomBug<4)
        {
            setImage("ant-with-food.png");
        }
        if(randomBug >= 4 && randomBug<6)
        {
            setImage("fly.png");
        }
        if(randomBug==6)
        {
            setImage("spider.png");
        }

    }

    /**
     * Act - do whatever the Bugs wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //get the y value of each bug in each iteration
        counter++;
        if(counter==1)
        {
            initialY = getY();
        }
        chase();
        attack();
    }    

    /**
     * Method chase
     * Follow the player as long as the bug doesn't cross the boundary
     * If the bug is the the top half of the world,
     * don't let it go below the y coordinate 283
     * If the bug is in the bottom half of the world,
     * don't let it go above the y coordinate 411 
     */
    private void chase()
    {
        List <Player> chasing = getObjectsInRange(100,Player.class);
        if(chasing.size()>0){
            Actor p =  chasing.get(0);
            int playerX = p.getX();
            int playerY = p.getY();
            turnTowards(playerX,playerY);
            move(1);
        }   

        if(initialY<450)
        {
            if(getY()>=283)
            {
                setLocation(getX(), 283);
            }
        }  

        if(initialY>450)
        {
            if(getY()<=411)
            {
                setLocation(getX(), 411);
            }
        }  
    }

    /**
     * Method attack
     * If the bug is touching the player
     * Attack after each 20 iterations
     * (ie tell the world to call the healthbar's diminishHealth method)
     */
    public void attack()
    {
        if(isTouching(Player.class))
        {
            attackCounter++;
            if(attackCounter>=20)
            {
                ((MyWorld)getWorld()).communication(1); 
                attackCounter=0;
            }
        }
    }
}
