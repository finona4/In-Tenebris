import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class WonGame here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class WonGame extends worldTitles
{
    //an int to keep track of transparency
    private int trans = 0;
    public WonGame()
    {
        getImage().setTransparency(trans);
    }

    /**
     * Act - do whatever the WonGame wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //if this has been added, the game has been won
        //play the victory music
        ((MyWorld) getWorld()).victoryMusic();
        //remove the flashlight
        Actor fl = getOneIntersectingObject(FlashLight.class);
        if(fl!=null)
        {
            getWorld().removeObject(fl);
        }
        //gradually increase the transparency, then stop the game
        trans = trans + 5;
        getImage().setTransparency(trans);
        if(trans>=240)
        {
            Greenfoot.stop();
        }
    }    
}
