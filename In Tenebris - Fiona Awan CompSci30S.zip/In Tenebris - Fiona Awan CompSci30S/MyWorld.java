import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class MyWorld extends World
{
    //two sounds 
    private GreenfootSound music = new GreenfootSound("bgsounds.mp3");
    private GreenfootSound music2 = new GreenfootSound("rickroll.mp3");
    //the healthbar and player up here so they can be accessed by all methods
    healthBar h = new healthBar();
    Player p = new Player();
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    public MyWorld()
    {    
        // Create a new world with 900x700 cells with a cell size of 1x1 pixels.
        super(900, 700, 1);
        //add the main character to the left of the world
        addObject(p, 100, 350);
        //add all the furniture
        prepare();
        //add the flashlight
        addObject(new FlashLight(), 223, 425);
        //add the health bar
        addObject(h, 86, 25);
        //add the score board
        addObject(new Scoreboard(p), 92, 56);
        //cover everything with the title screen and stop execution for now
        addObject(new Title(), getWidth()/2, getHeight()/2);
        Greenfoot.stop();
    }
    
    /**
     * Method started
     * Play the background critter sounds on a loop
     */
    public void started()
    {
        music.playLoop();
    }
    /**
     * Method victoryMusic
     * Runs when the game has been won (told to the world by the WonGame screen)
     * Stop the bg sounds and play the victory music ;)
     */
    public void victoryMusic()
    {
        music.stop();
        music2.play();
    }
    
    /**
     * Method communication
     * Runs when the main character has taken damage (told to the world by the Bugs)
     * Call the diminishHealth method in the healthBar class
     * (int harm is the amount that the bugs would like to hurt the character)
     * @param harm A parameter
     */
    public void communication(int harm)
    {
        h.diminishHealth(harm);
    }

    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Door door = new Door(p);
        addObject(door,663,283);;
        Door door2 = new Door(p);
        addObject(door2,663,411);
        Door door3 = new Door(p);
        addObject(door3,241,283);
        Door door4 = new Door(p);
        addObject(door4,241,411);

        MainWall1 mainWall1 = new MainWall1();
        addObject(mainWall1,101,283);
        MainWall1 mainWall12 = new MainWall1();
        addObject(mainWall12,101,411);
        MainWall1 mainWall13 = new MainWall1();
        addObject(mainWall13,381,283);
        MainWall1 mainWall14 = new MainWall1();
        addObject(mainWall14,525,283);
        MainWall1 mainWall15 = new MainWall1();
        addObject(mainWall15,799,283);
        MainWall1 mainWall16 = new MainWall1();
        addObject(mainWall16,375,411);
        MainWall1 mainWall17 = new MainWall1();
        addObject(mainWall17,524,411);
        MainWall1 mainWall18 = new MainWall1();
        addObject(mainWall18,799,411);
        MainWall2 mainWall2 = new MainWall2();
        addObject(mainWall2,450,154);
        MainWall2 mainWall22 = new MainWall2();
        addObject(mainWall22,450,100);
        MainWall2 mainWall23 = new MainWall2();
        addObject(mainWall23,450,539);
        MainWall2 mainWall24 = new MainWall2();
        addObject(mainWall24,450,599);
        BathWall1 bathWall1 = new BathWall1();
        addObject(bathWall1,36,184);
        BathWall2 bathWall2 = new BathWall2();
        addObject(bathWall2,144,20);
        BathWall2 bathWall22 = new BathWall2();
        addObject(bathWall22,685,4);
        BathWall1 bathWall12 = new BathWall1();
        addObject(bathWall12,850,112);
        BathWall1 bathWall13 = new BathWall1();
        addObject(bathWall13,50,571);
        BathWall2 bathWall23 = new BathWall2();
        addObject(bathWall23,220,677);
        BathWall2 bathWall24 = new BathWall2();
        addObject(bathWall24,767,690);
        BathWall1 bathWall14 = new BathWall1();
        addObject(bathWall14,874,512);

        Bugs bugs = new Bugs();
        addObject(bugs,593,47);
        Bugs bugs2 = new Bugs();
        addObject(bugs2,680,161);
        Bugs bugs3 = new Bugs();
        addObject(bugs3,588,168);
        Bugs bugs4 = new Bugs();
        addObject(bugs4,859,202);
        Bugs bugs5 = new Bugs();
        addObject(bugs5,801,156);
        Bugs bugs6 = new Bugs();
        addObject(bugs6,532,486);
        Bugs bugs7 = new Bugs();
        addObject(bugs7,562,559);
        Bugs bugs8 = new Bugs();
        addObject(bugs8,532,626);
        Bugs bugs9 = new Bugs();
        addObject(bugs9,745,479);
        Bugs bugs10 = new Bugs();
        addObject(bugs10,687,601);
        Bugs bugs11 = new Bugs();
        addObject(bugs11,209,40);
        Bugs bugs12 = new Bugs();
        addObject(bugs12,295,113);
        Bugs bugs13 = new Bugs();
        addObject(bugs13,189,196);
        Bugs bugs14 = new Bugs();
        addObject(bugs14,342,181);
        Bugs bugs15 = new Bugs();
        addObject(bugs15,89,520);
        Bugs bugs16 = new Bugs();
        addObject(bugs16,294,476);
        Bugs bugs17 = new Bugs();
        addObject(bugs17,275,542);
        Bugs bugs18 = new Bugs();
        addObject(bugs18,346,632);
        Bugs bugs19 = new Bugs();
        addObject(bugs19,269,650);

        Bed bed = new Bed();
        addObject(bed,229,56);
        Desk desk = new Desk();
        addObject(desk,339,36);
        Bed bed2 = new Bed();
        addObject(bed2,527,200);
        Desk desk2 = new Desk();
        addObject(desk2,535,36);
        Bed bed3 = new Bed();
        addObject(bed3,527,646);
        Bed bed4 = new Bed();
        addObject(bed4,369,646);
        Desk desk3 = new Desk();
        addObject(desk3,565,478);
        Desk desk4 = new Desk();
        addObject(desk4,337,478);
        Sink sink = new Sink();
        addObject(sink,768,26);
        Sink sink2 = new Sink();
        addObject(sink2,41,27);
        Soap soap2 = new Soap();
        addObject(soap2,748,8);
        Sink sink3 = new Sink();
        addObject(sink3,819,546);
        Soap soap3 = new Soap();
        addObject(soap3,797,529);
        Sink sink4 = new Sink();
        addObject(sink4,124,602);
        Soap soap4 = new Soap();
        addObject(soap4,21,11);
        Soap soap = new Soap();
        addObject(soap,139,586);
        Toilet toilet = new Toilet();
        addObject(toilet,824,35);
        Toilet toilet2 = new Toilet();
        addObject(toilet2,91,36);
        Toilet toilet3 = new Toilet();
        addObject(toilet3,869,554);
        Toilet toilet4 = new Toilet();
        addObject(toilet4,70,610);
        Vent vent = new Vent();
        addObject(vent,376,226);
        Vent vent2 = new Vent();
        addObject(vent2,140,455);
        Vent vent3 = new Vent();
        addObject(vent3,838,458);
        Vent vent4 = new Vent();
        addObject(vent4,738,235);
    }
}
