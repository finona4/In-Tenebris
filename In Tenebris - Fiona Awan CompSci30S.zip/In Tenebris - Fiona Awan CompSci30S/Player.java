import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class Player here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Player extends Actor
{
    //arrays to hold the images for each direction the player is walking/stannding in
    private GreenfootImage[] upstandingImages = new GreenfootImage[2];
    private GreenfootImage[] upwalkingImages = new GreenfootImage[2];
    private GreenfootImage[] downstandingImages = new GreenfootImage[2];
    private GreenfootImage[] downwalkingImages = new GreenfootImage[2];
    private GreenfootImage[] rightstandingImages = new GreenfootImage[2];
    private GreenfootImage[] rightwalkingImages = new GreenfootImage[2];
    private GreenfootImage[] leftstandingImages = new GreenfootImage[2];
    private GreenfootImage[] leftwalkingImages = new GreenfootImage[2];
    //keeps track of whether the player is moving or not
    private boolean keypressed = false;
    //an int to keep track of the # of keys collected
    public int keysCollected = 0;
    //an int to make sure only one key is counted at a time
    public int keyCounter = 0;
    //stores the direction that the player is currently facing
    private String direction = "right";
    //an int to keep track of the current image index
    private int currImage = 0;
    //an int to represent the speed of the animation
    private static final int SPEED = 15;
    private static final int walkingSPEED = 15;
    //an int to represent the delay in the animation
    private int delay = 0;
    //keeps track of whether the door nearby has been unlocked or not
    boolean doorUnlocked = true;
    /**
     * Player Constructor
     * Loads each image onto its array
     */
    public Player()
    {
        for(int i = 0; i<upstandingImages.length; i++)
        {
            upstandingImages[i] = new GreenfootImage("upStand"+(i+1)+".png");
        }
        for(int i = 0; i<upwalkingImages.length; i++)
        {
            upwalkingImages[i] = new GreenfootImage("upWalk"+(i+1)+".png");
        }
        for(int i = 0; i<downstandingImages.length; i++)
        {
            downstandingImages[i] = new GreenfootImage("downStand"+(i+1)+".png");
        }
        for(int i = 0; i<downwalkingImages.length; i++)
        {
            downwalkingImages[i] = new GreenfootImage("downWalk"+(i+1)+".png");
        }
        for(int i = 0; i<rightstandingImages.length; i++)
        {
            rightstandingImages[i] = new GreenfootImage("rightStand"+(i+1)+".png");
        }
        for(int i = 0; i<rightwalkingImages.length; i++)
        {
            rightwalkingImages[i] = new GreenfootImage("rightWalk"+(i+1)+".png");
        }
        for(int i = 0; i<leftstandingImages.length; i++)
        {
            leftstandingImages[i] = new GreenfootImage("leftStand"+(i+1)+".png");
        }
        for(int i = 0; i<leftwalkingImages.length; i++)
        {
            leftwalkingImages[i] = new GreenfootImage("leftWalk"+(i+1)+".png");
        }
        setImage(rightstandingImages[0]);
    }

    /**
     * Act - do whatever the Test wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        movement();
        bounceOffWalls();
        getDirection();
        checkForKeyandDoor();
    }    

    /**
     * Method getDirection
     * Used by the FlashLight class
     * Return the direction that the player is facing
     * @return The return value
     */
    public String getDirection()
    {
        return direction;
    }

    /**
     * Method checkForKeyandDoor
     * If the player is touching a key, increase the # of keys collected by one
     * If the player is simply near a key, tell the key to play the jingle
     * 
     * If the player is touching a door, return whether the door is locked or not
     */
    public void checkForKeyandDoor()
    {
        List <Keys> surrounding = getObjectsInRange(100, Keys.class);
        for (Keys go : surrounding)
        {
            if(isTouching(Keys.class))
            {
                go.getCollected(true);
                keyCounter++;
                if(keyCounter==1)
                {
                    keysCollected++;
                }
            }
            else if(!isTouching(Keys.class))
            {
                go.getCollected(false);
            }
        }
        keyCounter=0;
        Door d = (Door)getOneIntersectingObject(Door.class);
        if(d!=null)
        {
            if(!d.unlocked())
            {
                doorUnlocked=false;
            }
            if (d.unlocked())
            {
                doorUnlocked=true;
            }
        }
    }

    /**
     * Method numCollected
     * Used by the Doors class
     * Return the total # of keys collected so far
     * @return The return value
     */
    public int numCollected()
    {
        return keysCollected;
    }

    /**
     * Method bounceOffWalls
     * Either bounce up or bounce down from (ie don't go through) the walls 
     * - Based on the player position relative to the wall
     * Tell the animation method to stand
     */
    private void bounceOffWalls()
    {
        //gives us an actor that is under us (at a given offset at location)
        Actor underMain = getOneObjectAtOffset(0, getImage().getHeight()/2, MainWall1.class);
        Actor underBath = getOneObjectAtOffset(0, getImage().getHeight()/2, BathWall1.class);
        Actor underDoor = getOneObjectAtOffset(0, getImage().getHeight()/2, Door.class);
        if(isTouching(MainWall1.class) || isTouching(BathWall1.class) || (isTouching(Door.class) && !doorUnlocked))
        {
            setLocation(getX(), getY()+10);
            keypressed=false;
        }
        if(underMain!=null || underBath!=null || (underDoor!=null && !doorUnlocked))
        {
            setLocation(getX(), getY()-20);
            keypressed=false;
        }
        Actor leftMain2 = getOneObjectAtOffset(0, getImage().getHeight()/2, MainWall2.class);
        Actor leftBath2 = getOneObjectAtOffset(0, getImage().getHeight()/2, BathWall2.class);
        Actor rightMain2 = getOneObjectAtOffset(-getImage().getWidth()+50, getImage().getHeight()/2, MainWall2.class);
        Actor rightBath2 = getOneObjectAtOffset(-getImage().getWidth()+50, getImage().getHeight()/2, BathWall2.class);
        if(rightMain2!=null || rightBath2!=null)
        {
            setLocation(getX()+20, getY());
            keypressed=false;
        }
        if(leftMain2!=null || leftBath2!=null)
        {
            setLocation(getX()-10, getY());
            keypressed=false;
        }
    }

    /**
     * Method movement
     * Animate the player
     */
    private void movement()
    {
        if(!keypressed)
        {
            if(direction=="right")
            {
                delay++;
                if (delay==SPEED)
                {
                    currImage++;
                    if(currImage>=rightstandingImages.length)
                    {
                        currImage=0;
                    }
                    setImage(rightstandingImages[currImage]); 
                    delay = 0;
                }    
            }
            if(direction=="left")
            {
                delay++;
                if (delay==SPEED)
                {
                    currImage++;
                    if(currImage>=leftstandingImages.length)
                    {
                        currImage=0;
                    }
                    setImage(leftstandingImages[currImage]); 
                    delay = 0;
                }    
            }
            if(direction=="up")
            {
                delay++;
                if (delay==SPEED)
                {
                    currImage++;
                    if(currImage>=upstandingImages.length)
                    {
                        currImage=0;
                    }
                    setImage(upstandingImages[currImage]); 
                    delay = 0;
                }    
            }
            if(direction=="down")
            {
                delay++;
                if (delay==SPEED)
                {
                    currImage++;
                    if(currImage>=downstandingImages.length)
                    {
                        currImage=0;
                    }
                    setImage(downstandingImages[currImage]); 
                    delay = 0;
                }    
            }
        }
        if(Greenfoot.isKeyDown("right"))
        {
            delay++;
            if (delay==walkingSPEED)
            {
                currImage++;
                if(currImage>=rightwalkingImages.length)
                {
                    currImage=0;
                }
                setImage(rightwalkingImages[currImage]); 
                delay = 0;
            }  
            setLocation(getX()+2, getY());
            keypressed=true;
            direction="right";
        }
        if(Greenfoot.isKeyDown("left"))
        {
            delay++;
            if (delay==walkingSPEED)
            {
                currImage++;
                if(currImage>=leftwalkingImages.length)
                {
                    currImage=0;
                }
                setImage(leftwalkingImages[currImage]); 
                delay = 0;
            }  
            setLocation(getX()-2, getY());
            keypressed=true;
            direction="left";
        }
        if(Greenfoot.isKeyDown("up"))
        {
            delay++;
            if (delay==walkingSPEED)
            {
                currImage++;
                if(currImage>=upwalkingImages.length)
                {
                    currImage=0;
                }
                setImage(upwalkingImages[currImage]); 
                delay = 0;
            }  
            setLocation(getX(), getY()-2);
            keypressed=true;
            direction="up";
        }
        if(Greenfoot.isKeyDown("down"))
        {
            delay++;
            if (delay==walkingSPEED)
            {
                currImage++;
                if(currImage>=downwalkingImages.length)
                {
                    currImage=0;
                }
                setImage(downwalkingImages[currImage]); 
                delay = 0;
            }  
            setLocation(getX(), getY()+2);
            keypressed=true;
            direction="down";
        }
        if (!Greenfoot.isKeyDown("right") && !Greenfoot.isKeyDown("left") && !Greenfoot.isKeyDown("up") && !Greenfoot.isKeyDown("down"))
        {
            keypressed=false;
        }
    }
}