import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class DoorExit here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class DoorExit extends theFurniture
{
    public DoorExit() 

    { 
        GreenfootImage img = new GreenfootImage("EXIT", 40, Color.WHITE, Color.GREEN);
        setRotation(90);
        setImage(img);
    } 

    /**
     * Act - do whatever the DoorExit wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        //if the player reaches the exit, switch to the victory screen
        if(isTouching(Player.class))
        {
            getWorld().addObject(new WonGame(), getWorld().getWidth()/2, getWorld().getHeight()/2);
        }
    }    
}
