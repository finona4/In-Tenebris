import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Prompt here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Prompt extends Actor
{
    String text;
    public Prompt(String message)
    {
        text = message;
        GreenfootImage img = new GreenfootImage(message, 25, Color.WHITE, Color.BLACK);
        setImage(img);
    }
    
    /**
     * Act - do whatever the Prompt wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    
    
    public void removeThis()
    {
        getWorld().removeObject(this);
    }
}
