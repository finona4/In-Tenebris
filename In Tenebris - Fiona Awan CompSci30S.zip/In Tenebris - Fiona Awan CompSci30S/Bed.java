import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Bed here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Bed extends theFurniture
{
    private Prompt p;
    //keeps track of whether the player is next to the bed or not
    boolean touching = false;
    //keeps track of whether the player has gotten the key or not
    boolean gotKey = false;
    //an int to make the prompt get added only once
    int counter = 0;
    public Bed()
    {
        getImage().scale(100, 110);
    }

    /**
     * Act - do whatever the Bed wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        keyAndPrompt();
    }

    /**
     * Method keyAndPrompt
     * If the player is next to the bed, display the prompt to press c
     *  - If c is pressed near the top-left bed and no key has been collected yet
     *  - Add a key
     *  If the player leaves the bed, remove the prompt
     */
    public void keyAndPrompt()
    {
        if(isTouching(Player.class))
        {
            if(counter==0)
            {
                p = new Prompt("Crouch: c");
                counter=1;
            }
            getWorld().addObject(p, 60, 86);
            touching=false;
            if(Greenfoot.isKeyDown("c") && getX()==229 && !gotKey)
            {
                Keys keys = new Keys();
                getWorld().addObject(keys,229,42);
                gotKey = true;
            }
        }
        if(!isTouching(Player.class) && !touching)
        {
            touching=true;
            counter=0;
            if(p!=null)
            {
                p.removeThis();
            }
        }
    }
}    
