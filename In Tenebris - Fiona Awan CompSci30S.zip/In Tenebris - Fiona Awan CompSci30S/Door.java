import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Door here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Door extends theFurniture
{
    //keeps track of whether the door has been unlocked yet
    boolean unlocked=false;
    Player player;
    //an int to keep track of the # of keys collected
    int keysCollected = 0;
    //an int to make sure the roomba is only added once
    int roombaCounter = 0;
    //keeps track of whether the fourth key has been collected or not
    boolean escape = false;
    public Door(Player p)
    {
        player = p;
        GreenfootImage doors = new GreenfootImage(80, 50);
        doors.setColor(Color.RED);
        doors.fill();
        setImage(doors);
    }

    /**
     * Act - do whatever the Door wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        commUnlocked();
    }    

    /**
     * Method commUnlocked
     * Open a specific door based on the number of keys that have been collected
     * Change the color of an unlocked door from red to green
     */
    public void commUnlocked()
    {
        if(player.numCollected()>=4)
        {
            if(!escape)
            {
                getWorld().addObject(new DoorExit(), 800, 350);
                escape=true;
            }
        }
        if(player.numCollected()>=3)
        {
            if(getX()==241 && getY()==411)
            {
                roombaCounter++;
                if(roombaCounter==1)
                {
                    getWorld().addObject(new Roomba(), 35, 535);
                }
                GreenfootImage openDoor = new GreenfootImage(80, 50);
                openDoor.setColor(Color.GREEN);
                openDoor.fill();
                setImage(openDoor);
                unlocked = true;
            }
        }
        else if(player.numCollected()>=2)
        {
            if(getX()==663 && getY()==283)
            {
                GreenfootImage openDoor = new GreenfootImage(80, 50);
                openDoor.setColor(Color.GREEN);
                openDoor.fill();
                setImage(openDoor);
                unlocked = true;
            }
        }
        else if(player.numCollected()>=1)
        {
            if(getX()==663 && getY()==411)
            {
                GreenfootImage openDoor = new GreenfootImage(80, 50);
                openDoor.setColor(Color.GREEN);
                openDoor.fill();
                setImage(openDoor);
                unlocked = true;
            }
        }
        else if(player.numCollected()>=0 )
        {
            if(getX()==241 && getY()==283)
            {
                GreenfootImage openDoor = new GreenfootImage(80, 50);
                openDoor.setColor(Color.GREEN);
                openDoor.fill();
                setImage(openDoor);
                unlocked = true;
            }
        }
        else
        {
            unlocked = false;
        }
    }

    /**
     * Method unlocked
     * Used by the Player class
     * Returns whether the door that the player is touching has been unlocked or not
     * @return The return value
     */
    public boolean unlocked()
    {
        return unlocked;
    }
}
