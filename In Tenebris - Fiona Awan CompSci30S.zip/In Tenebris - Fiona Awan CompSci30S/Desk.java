import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Desk here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Desk extends theFurniture
{
    Prompt p1;
    Prompt p2;
    //an array that carries the user-inputted password
    String[] passwordInput = new String[8];
    //stores the laptop's password (volucris means flying creature)
    String password = "volucris";
    //stores the completed user-inputted password
    String inputtedPassword;
    //an int to make sure a password can only be inputted once
    int passCounter = 0;
    //keeps track of whether the player is near the desk or not
    boolean touching = false;
    //keeps track of whether the user has acquried the password or not
    boolean gotPass = false;
    //an int to make the prompt get added only once
    int counter = 0;
    public Desk()
    {
        getImage().scale(110, 80);
    }

    /**
     * Act - do whatever the Desk wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        keyAndPrompt();
    }    

    /**
     * Method keyAndPrompt
     * If the player is near the desk, prompt the player to press v
     * - If v is pressed and the player is near the bottom-right desk
     * - remove the 'press v' prompt, and prompt the player to type the password
     * If every index in the password array has been filled and it matches the
     * password on the laptop
     * Add a key
     * If the player leaves the desk, remove the prompt
     */
    public void keyAndPrompt()
    {
        if(isTouching(Player.class))
        {
            if(counter==0)
            {
                p1 = new Prompt("Laptop: v");
                counter=1;
            }
            getWorld().addObject(p1, 102, 86);
            touching=false;
            if(Greenfoot.isKeyDown("v") && getX()==565)
            {
                p1.removeThis();
                if(counter==1)
                {
                    p1 = new Prompt("Password: volucris");
                    counter=2;
                }
                getWorld().addObject(p1, 102, 86);
                gotPass=true;
            }
            if(gotPass)
            {
                if(Greenfoot.isKeyDown("v"))
                {
                    passwordInput[0] = "v";
                }
                if(Greenfoot.isKeyDown("o"))
                {
                    passwordInput[1] = "o";
                }
                if(Greenfoot.isKeyDown("l"))
                {
                    passwordInput[2] = "l";
                }
                if(Greenfoot.isKeyDown("u"))
                {
                    passwordInput[3] = "u";
                }
                if(Greenfoot.isKeyDown("c"))
                {
                    passwordInput[4] = "c";
                }
                if(Greenfoot.isKeyDown("r"))
                {
                    passwordInput[5] = "r";
                }
                if(Greenfoot.isKeyDown("i"))
                {
                    passwordInput[6] = "i";
                }
                if(Greenfoot.isKeyDown("s"))
                {
                    passwordInput[7] = "s";
                }
                if(passwordInput[7]=="s" && passCounter==0)
                {
                    inputtedPassword = "volucris";
                    if(inputtedPassword==password)
                    {
                        Keys keys2 = new Keys();
                        getWorld().addObject(keys2,587,475);
                        passCounter=1;
                    }
                }
            }
        }
        if(!isTouching(Player.class) && !touching)
        {
            touching=true;
            if(p1!=null && counter==1 && !gotPass)
            {
                counter=0;
                p1.removeThis();
            }
            else if(p1!=null && counter==2 && gotPass)
            {
                counter=1;
                p1.removeThis();
            }
        }
    }
}
