import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Roomba here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Roomba extends theFurniture
{
    Prompt p;
    //keeps track of whether the player is next to the vacuum or not
    boolean touching = false;
    //a jingle sound
    GreenfootSound sound = new GreenfootSound("jingle.mp3");
    //an int that counts how long the vent has been vacuumed
    int vacuumCounter=0;
    //an int to make the prompt get added only once
    int counter = 0;
    public Roomba()
    {
        getImage().scale(60,60);
    }

    /**
     * Act - do whatever the Roomba wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        keyAndPrompt();
    }   

    /**
     * Method keyAndPrompt
     * If the player is next to the roomba, display the prompt to drag the mouse
     * Follow the mouse as it's dragging the roomba
     * If the player has dragged the vacuum over the vent for 100 iterations
     * - Add the key
     * If the player leaves the vacuum, remove the prompt
     */
    public void keyAndPrompt()
    {
        if(isTouching(Player.class))
        {
            if(counter==0)
            {
                p = new Prompt("Vacuum: hold mouse");
                counter=1;
            }
            getWorld().addObject(p, 110, 86);
            touching=false;
        }
        if(!isTouching(Player.class) && !touching)
        {
            counter=0;
            touching=true;
            if(p!=null)
            {
                p.removeThis();
            }
        }
        if(Greenfoot.mouseDragged(this))
        {
            int x = Greenfoot.getMouseInfo().getX();
            int y = Greenfoot.getMouseInfo().getY();
            setLocation(x, y);
            Greenfoot.playSound("vacuum.mp3");
            if(getX()>=108 && getX()<=178 && getY()>=433 && getY()<=478)
            {
                vacuumCounter++;
                sound.play();
                if(vacuumCounter>=100)
                {
                    sound.stop();
                    Keys keys4 = new Keys();
                    getWorld().addObject(keys4,139,455);
                }
            }
        }
    }
}
