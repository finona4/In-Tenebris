import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Scoreboard here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Scoreboard extends Actor
{
    Player p;
    //the text that the scoreboard will show
    String message = "Keys Collected:";
    //keeps track of the total keys collected
    int totalKeysCollected = 0;
    public Scoreboard(Player player)
    {
        p = player;
        GreenfootImage img = new GreenfootImage(message + p.numCollected(), 25, Color.WHITE, Color.BLACK);
        setImage(img);
    }

    /**
     * Act - do whatever the Scoreboard wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        updateMessage();
    } 

    /**
     * Method updateMessage
     * Update the scoreboard for when a new key is collected
     */
    public void updateMessage()
    {
        totalKeysCollected = p.numCollected();
        GreenfootImage img = new GreenfootImage(message + totalKeysCollected, 25, Color.WHITE, Color.BLACK);
        setImage(img);
    }
}
