import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class FlashLight here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class FlashLight extends Actor
{
    //an array to hold each Flashlight image 
    GreenfootImage[] img = new GreenfootImage[4];
    
    /**
     * FlashLight Constructor
     * Load each direction onto the img array
     */
    public FlashLight()
    {
        for (int i = 0; i<img.length; i++)
        {
            if(i==0)
            {
                img[i] = new GreenfootImage("flashlightRight.png");
            }
            if(i==1)
            {
                img[i] = new GreenfootImage("flashlightLeft.png");
            }
            if(i==2)
            {
                img[i] = new GreenfootImage("flashlightUp.png");
            }
            if(i==3)
            {
                img[i] = new GreenfootImage("flashlightDown.png");
            }
        }
    }

    /**
     * Act - do whatever the FlashLight wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        changeDirection();
    }    

    /**
     * Method changeDirection
     * Change the direction of the picture depending on the direction of the player
     * And move with the player
     */
    private void changeDirection()
    {
        Player p = (Player)getOneIntersectingObject(Player.class);
        if (p.getDirection()=="right")
        {
            setImage(img[0]);
            setLocation(p.getX()-44, p.getY());
        }
        if (p.getDirection()=="left")
        {
            setImage(img[1]);
            setLocation(p.getX()+44, p.getY());
        }
        if (p.getDirection()=="up")
        {
            setImage(img[2]);
            setLocation(p.getX(), p.getY()+44);
        }
        if (p.getDirection()=="down")
        {
            setImage(img[3]);
            setLocation(p.getX(), p.getY()-44);
        }
    }
    
    /**
     * Method deleteFlashlight
     * Runs when the game has been won and light returns to the building
     */
    public void deleteFlashlight()
    {
        getWorld().removeObject(this);
    }
}
