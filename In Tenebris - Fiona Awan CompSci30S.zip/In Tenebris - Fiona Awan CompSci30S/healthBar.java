import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class healthBar here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class healthBar extends Actor
{
    //the healthbar image up here so all methods can access it
    GreenfootImage img = new GreenfootImage(150, 25);
    //an int to represent the damage done to the player by the bug
    int damage;
    //ints to store the rgb values
    int r = 0;
    int g = 0;
    int b = 255;
    Color c;
    
    /**
     * healthBar Constructor
     * Set the image to be a blue bar
     */
    public healthBar()
    {
        img.setColor(Color.BLUE);
        img.fill();
        setImage(img);
    }

    /**
     * Act - do whatever the healthBar wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
    }    

    /**
     * Method diminishHealth
     * Runs when a bug has attacked the player
     * Display the amount of total damage by shrinking the bar
     * If there is no bar left, game over
     * (I tried changing the color of the bar after damage but it doesn't work)
     * @param harm A parameter
     */
    public void diminishHealth(int harm)
    {
        if(getImage().getWidth()>1)
        {
            damage = harm;
            img = new GreenfootImage(getImage().getWidth()-damage, getImage().getHeight());
            c = new Color(r, g, b);
            Color n = new Color(c.getRed()+harm, c.getGreen(), c.getBlue()-harm);
            img.setColor(n);
            img.fill();
            setImage(img);
        }
        else
        {
            getWorld().addObject(new GameOver(), getWorld().getWidth()/2, getWorld().getHeight()/2);
        }
    }
}
