
import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Soap here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Soap extends theFurniture
{
    Prompt p;
    //an int to count how long the soap has been under water
    int washCounter=0;
    //keeps track of whether the player is next to the soap or not
    boolean touching = false;
    //keeps track of whether the key has been unvealed or not
    boolean keyCollected = false;
    //keeps track of whether the soap has run out or not
    boolean washAway = false;
    //an int to make the prompt get added only once
    int counter = 0;
    public Soap()
    {
        getImage().scale(30, 20);
    }

    /**
     * Act - do whatever the Soap wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act() 
    {
        // Add your action code here.
        keyAndPrompt();
    }    

    /**
     * Method keyAndPrompt
     * If the player is next to the soap, display the prompt to hold v
     *  - If v is held near the top-right soap bar for 400 iterations
     *  - Add a key
     *  - Remove the bar of soap (as it has been washed away)
     * If the player leaves the soap, remove the prompt
     */
    public void keyAndPrompt()
    {
        if(isTouching(Player.class))
        {
            if(counter==0)
            {
                p = new Prompt("Wash hands: hold v");
                counter=1;
            }
            getWorld().addObject(p, 107, 86);
            touching=false;
            if(Greenfoot.isKeyDown("v") && getX()==748 && !keyCollected)
            {
                if(washCounter==0)
                {
                    Greenfoot.playSound("sink.mp3");
                }
                washCounter++;
                if(washCounter>=400)
                {
                    Keys keys3 = new Keys();
                    getWorld().addObject(keys3,749,10);
                    keyCollected=true;
                    p.removeThis();
                    washAway=true;
                }
            }
        }
        if(!isTouching(Player.class) && !touching)
        {
            counter=0;
            touching=true;
            if(p!=null)
            {
                p.removeThis();
            }
        }
        if(washAway==true)
        {
            getWorld().removeObject(this);
        }
    }
}
